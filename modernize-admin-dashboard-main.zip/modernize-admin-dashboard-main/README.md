# [Modernize Free Next Js Admin Template](https://modernize-nextjs-free.vercel.app/)

<!-- Main image of Template -->
[![Next Js](https://adminmart.com/wp-content/uploads/2023/03/modernize-free-next-js-admin-template.png)](#)

    
